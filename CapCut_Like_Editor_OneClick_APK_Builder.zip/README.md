One-Click GitHub-ready project. Upload this repo to GitHub, enable Actions, and the workflow will try to build an APK.

If build fails, share the Actions logs and I'll help fix.
